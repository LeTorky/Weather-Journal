// Require function places all the data of a specific module into a variable
// after initiation the module by writing the app name followed by () the module gets instantiated

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const port = 8000;
let appData = {};


// After instantiating an express application into a variable named app
// we can start using a method called .use in order to link the needed middleware into our application
// this middleware is a set of functions that deal with the web requests during its lifecycle
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static('client'));
// By using the listen method we can listen for the initiation of the server and run a callback function
const server = app.listen(port,listening);
function listening(){
    console.log('server running');
    console.log(`running on localhost: ${port}`);
}
// By using a get method we are listening for get requests in order to send data.
app.get("/old_data",function(req,res){
   res.send(appData);
});
// By Using a post method we are listening for a post request by the user to receive the data sent by
// the user and return something expected

app.post("/post",function(req,res){
    if (req.body){
        appData = req.body;
        let datestring = new Date();
        datestring = datestring.toDateString();
        appData.date = datestring;
    }
});
