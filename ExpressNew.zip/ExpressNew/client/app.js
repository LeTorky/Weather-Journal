//A fetching function to retrieve last existing data if exists
getOriginalData = async () =>{
    const data = await fetch('/old_data');
    try{
        return data.json();
    }
    catch(error){
        return error
    }
}
//Function to update Elements with data
updateUI = (data) => {
    let flag=0;
    for(let att in data){
        if (att){
            flag =1;
        }
    }
    if(flag){
        const edate = document.getElementById("opdate");
        const elocation = document.getElementById("oplocation");
        const eweather = document.getElementById("opweather");
        const efeeling = document.getElementById("opfeeling");
        edate.innerHTML = data.date;
        elocation.innerHTML = data.name;
        eweather.innerHTML = "It's "+data.main.temp+' K, '+data.weather[0].description;
        efeeling.innerHTML = 'Iam feeling '+data.feeling;
        const container = document.getElementsByClassName('output_container')[0];
        container.style.display = 'flex';
    }
}
// Initation of fetch function upon opening page
getOriginalData().then(data => {updateUI(data);});

// Function to fetch data from the server
fetchData = async (postalCode) =>{
    const postData = await fetch(`https://api.openweathermap.org/data/2.5/weather?zip=${postalCode},&appid=ee800e1e7ab999936817e7fea800a539`);
    try{
        return postData.json()
    }
    catch(error){
        return error
    }
}

// Function to post data fetched
postData = async (data) =>{
    const postedData = await fetch("/post",{
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
        },
        body:JSON.stringify(data),
    })
}

// Event Listener to Activate the Post Function
const button = document.getElementById('button');
button.addEventListener('click',() => {
    let zip = document.getElementById('postal').value;
    zip = parseInt(zip);
    const feeling = document.getElementById('feeling').value;
    let flag = 0;
    // const checkfetch = fetchData(zip).then(data=>{if()})
    if (!isNaN(zip)){
        fetchData(zip).then(data=>{
            if(data.cod !== '404'){
                data.feeling = feeling;postData(data);
                getOriginalData().then(data => {updateUI(data);});
            }
            else{
                alert('This zip code doesnt exist');
            }
        });
    }
    else{
        alert('Please enter a valid zipcode');
    }
});
